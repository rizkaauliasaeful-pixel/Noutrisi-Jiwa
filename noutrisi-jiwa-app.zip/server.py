# Server Lokal Real-Time Noutrisi Jiwa
# Menghubungkan HP Siswa (IP 1) ke HP/Laptop Admin Bu Rizka (IP 2)

import http.server
import socketserver
import json
import os

PORT = 8000
DATA_FILE = "laporan_siswa.json"

# Inisialisasi file data jika belum ada
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump([], f)

class NoutrisiJiwaHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # API untuk mengambil daftar laporan di Dasbor Bu Rizka
        if self.path == '/api/reports':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                self.wfile.write(f.read().encode('utf-8'))
            return
        
        # Sajikan file web biasa (index.html, manifest.json, dll)
        return super().do_GET()

    def do_POST(self):
        # API saat Siswa (HP 1) mengirim jawaban konseling
        if self.path == '/api/submit':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            new_report = json.loads(post_data.decode('utf-8'))

            # Baca data lama dan tambahkan laporan baru
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                reports = json.load(f)
            
            reports.insert(0, new_report)

            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(reports, f, indent=2, ensure_ascii=False)

            # Kirim respons sukses ke HP Siswa
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {"status": "success", "message": "Laporan tersimpan di Bu Rizka"}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            return

print(f"=======================================================")
print(f"🚀 SERVER NOUTRISI JIWA AKTIF DI PORT {PORT}!")
print(f"👉 Buka di Laptop Bu Rizka: http://localhost:{PORT}")
print(f"📱 Buka di HP Siswa (Satu Wi-Fi): http://172.20.10.4:{PORT}")
print(f"=======================================================")

with socketserver.TCPServer(("", PORT), NoutrisiJiwaHandler) as httpd:
    httpd.serve_forever()
